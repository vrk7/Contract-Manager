"""
Backend package root.
"""
